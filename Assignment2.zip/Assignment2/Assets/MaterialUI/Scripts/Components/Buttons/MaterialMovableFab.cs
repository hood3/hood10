﻿//  Copyright 2017 MaterialUI for Unity http://materialunity.com
//  Please see license file for terms and conditions of use, and more information.

using UnityEngine;

namespace MaterialUI
{
    [AddComponentMenu("MaterialUI/Material Movable Fab", 100)]
    public class MaterialMovableFab : MonoBehaviour { }
}

