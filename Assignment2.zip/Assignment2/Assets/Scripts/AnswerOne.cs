﻿//Byron hood
//Game Programming
//Assignment#2
//02/09/2019
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AnswerOne : MonoBehaviour
{
    public static List<string> firstchoice = new List<string>();
    public void loadanswerOne()
    {
        string filePath = @"answer1.csv";
        string[] lines = System.IO.File.ReadAllLines(filePath);
        foreach (string line in lines)
        {
            string[] parts = line.Split(new char[] { ',' });
            foreach (string p in parts)
            {
                string answer1 = p.Trim(' ', '\t', '\n', '\r', '"');
                firstchoice.Add(answer1);
            }
        }
    }

    void Start()
    {
        loadanswerOne();
    }
    
    void Update()
    {
        if (GameControl.randQuestion > -1)
        {
            GetComponent<Text>().text = firstchoice[GameControl.randQuestion];
        }

    }
    public void onClick()
    {
        GameControl.selectedAnswer = gameObject.name;
        GameControl.choiceSelected = "y";
    }
}
