﻿//Byron hood
//Game Programming
//Assignment#2
//02/09/2019
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SoreControl : MonoBehaviour {
    public static int PlayerScore = 0;
    public static int TotalScore = 0;
    private int points = 100;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        
        if (GameControl.correctAnswer[GameControl.randQuestion] == GameControl.selectedAnswer)
        {            
            TotalScore = PlayerScore + points;            
            GetComponent<Text>().text = "Score: " + TotalScore;
        }
        
    }
}
