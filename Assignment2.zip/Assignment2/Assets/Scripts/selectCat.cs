﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class selectCat : MonoBehaviour {
    public static string catTopic;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void onClick ()
    {
        catTopic = gameObject.name;
        SceneManager.LoadScene("Main");
        
    }
}
