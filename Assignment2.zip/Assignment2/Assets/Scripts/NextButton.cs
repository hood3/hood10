﻿//Byron hood
//Game Programming
//Assignment#2
//02/09/2019
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NextButton : MonoBehaviour {
    
    void Start () {}	
	
	void Update () {}
    public void onClick ()
    {        
        GameControl.randQuestion = -1;
        SoreControl.PlayerScore = SoreControl.TotalScore;  
    }
}
