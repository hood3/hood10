﻿//Byron hood
//Game Programming
//Assignment#2
//02/09/2019
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AnswerThree : MonoBehaviour
{
    public static List<string> thirdchoice = new List<string>();
    public void loadanswerThree()
    {
        string filePath = @"answer3.csv";
        string[] lines = System.IO.File.ReadAllLines(filePath);
        foreach (string line in lines)
        {
            string[] parts = line.Split(new char[] { ',' });
            foreach (string p in parts)
            {
                string answer3 = p.Trim(' ', '\t', '\n', '\r', '"');
                thirdchoice.Add(answer3);
            }
        }
    }

    void Start()
    {
        loadanswerThree();
    }    
    void Update()
    {
        if (GameControl.randQuestion > -1)
        {
            GetComponent<Text>().text = thirdchoice[GameControl.randQuestion];
        }

    }
    public void onClick ()
    {
        GameControl.selectedAnswer = gameObject.name;
        GameControl.choiceSelected = "y";
    }
}
