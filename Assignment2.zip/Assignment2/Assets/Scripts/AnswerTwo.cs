﻿//Byron hood
//Game Programming
//Assignment#2
//02/09/2019
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AnswerTwo : MonoBehaviour
{
    public static List<string> secondchoice = new List<string>();
    public void loadanswerTwo()
    {
        string filePath = @"answer2.csv";
        string[] lines = System.IO.File.ReadAllLines(filePath);
        foreach (string line in lines)
        {
            string[] parts = line.Split(new char[] { ',' });
            foreach (string p in parts)
            {
                string answer2 = p.Trim(' ', '\t', '\n', '\r', '"');
                secondchoice.Add(answer2);
            }
        }
    }

    void Start()
    {
        loadanswerTwo();
    }
    
    void Update()
    {
        if (GameControl.randQuestion > -1)
        {
            GetComponent<Text>().text = secondchoice[GameControl.randQuestion];
        }

    }
    public void onClick()
    {
        GameControl.selectedAnswer = gameObject.name;
        GameControl.choiceSelected = "y";
    }
}
