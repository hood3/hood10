﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class screencontrol : MonoBehaviour
{

    public void StartGame()
    {
        SceneManager.LoadScene("Menu");
    }
}

