﻿//Byron hood
//Game Programming
//Assignment#2
//02/09/2019
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.UI;

public class GameControl : MonoBehaviour {
    public static List<string> questions = new List<string>();
    public static List<string> correctAnswer = new List<string>();
    public Transform ResultsObj;
    public static string selectedAnswer;
    public static string choiceSelected = "n";
    public static int randQuestion = -1;
    public int catMod = 0;    

    public void loadQuestions()
    {
        string filePath = @"Questions.csv";
        string[] lines = System.IO.File.ReadAllLines(filePath);
        foreach (string line in lines)
        {
            string[] parts = line.Split(new char[] { ',' });
            foreach (string p in parts)
            {
                string question = p.Trim(' ', '\t', '\n', '\r', '"');
                questions.Add(question);
            }
        }
    }
    public void loadcorrectAnswers()
    {
        string filePath = @"CorrectAnswers.csv";
        string[] lines = System.IO.File.ReadAllLines(filePath);
        foreach (string line in lines)
        {
            string[] parts = line.Split(new char[] { ',' });
            foreach (string p in parts)
            {
                string answer = p.Trim(' ', '\t', '\n', '\r', '"');
                correctAnswer.Add(answer);
            }
        }
    }
    void Start () {
        loadQuestions();
        loadcorrectAnswers();
        if (selectCat.catTopic == "OU Football")
        {
            catMod = 10;
        }
        if (selectCat.catTopic == "Capitals")
        {
            catMod = 0;
        }
        if (selectCat.catTopic == "Spanish")
        {
            catMod = 20;
        }
    }	
	void Update () {
        if (randQuestion == -1)
        {
            randQuestion = Random.Range(0+catMod, 10+catMod);            
        }

        if (randQuestion > -1)
        {
            GetComponent<Text>().text = questions[randQuestion];            
        }
        if (choiceSelected == "y")
        {
            choiceSelected = "n";
            if (correctAnswer[randQuestion] == selectedAnswer)
            {
                ResultsObj.GetComponent<TextMesh>().text = "Correct!! Click on Next to continue.";                
            }
            else
            {
                ResultsObj.GetComponent<TextMesh>().text = "Wrong!! Click on Next to continue.";
            }               

        }
        
    }
}
